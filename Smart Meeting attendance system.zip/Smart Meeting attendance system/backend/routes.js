import express from 'express';
import { login, register } from './controllers/authController.js';
import { createMeeting } from './controllers/meetingController.js';
import { getMeetings } from './controllers/meetingController.js';
import { attendMeeting } from './controllers/meetingController.js';
import auth from './middleware/auth.js';
const router = express.Router();

// 🧩 AUTH ROUTES
router.post('/auth/register', register);
router.post('/auth/login', login);

// 📅 MEETING ROUTES
router.post('/meetings', auth, createMeeting);
router.get('/meetings', auth, getMeetings);
router.post('/meetings/:id/attend', auth, attendMeeting);

export default router;