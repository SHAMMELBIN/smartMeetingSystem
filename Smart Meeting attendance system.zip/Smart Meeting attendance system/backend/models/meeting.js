import mongoose from 'mongoose';

const meetingSchema = new mongoose.Schema({
  topic: { type: String, required: true },
  amount: { type: Number, default: 0 },
  startTime: { type: Date, required: true },
  endTime: { type: Date, required: true },
  qrData: { type: Object },
  attendees: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
});

export default mongoose.model('Meeting', meetingSchema);
