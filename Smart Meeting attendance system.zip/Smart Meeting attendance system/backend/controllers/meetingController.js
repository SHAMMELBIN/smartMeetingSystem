import Meeting from "../models/meeting.js";

export async function createMeeting(req, res) {
  try {
    const { topic, amount, startTime, endTime } = req.body;

    const meetings = await Meeting.create({
      topic,
      amount,
      startTime,
      endTime,
      qrData: { topic, startTime },
    });

    res.status(201).json({ meetings });
  } catch (err) {
    res.status(500).json({ message: 'Error creating meeting',error:err });
  }
}

export async function getMeetings(req, res) {
  try {
    const meetings = await Meeting.find();
    res.json(meetings);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching meetings' });
  }
}

export async function attendMeeting(req, res) {
  try {
    const { id } = req.params;
    const meetings = await Meeting.findById(id);
    if (!meetings) return res.status(404).json({ message: 'Meeting not found' });

    if (!meetings.attendees.includes(req.user)) {
      meetings.attendees.push(req.user);
      await meetings.save();
    }

    res.json({ message: 'Attendance marked' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to mark attendance' });
  }
}
