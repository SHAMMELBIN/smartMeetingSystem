import { Routes, Route, NavLink } from 'react-router-dom';
import PrivateRoute from './Components/PrivateRoute.jsx';
import LoginPage from './Login.jsx';
import CreateMeeting from './Pages/CreateMeeting.jsx';
import QRPage from './Pages/QRPage.jsx';
import AttendPage from './Pages/Attendpage.jsx';
import Dashboard from './Pages/Dashboard.jsx';
import './App.css';  // 👈 Import global styles
import RegisterPage from './RegisterPage.jsx';


export default function App() {
  return (
    <div className="app">
      <nav className="nav">
        <NavLink to="/" className={({ isActive }) => (isActive ? 'active' : '')}>
          Dashboard
        </NavLink>
        <NavLink to="/create" className={({ isActive }) => (isActive ? 'active' : '')}>
          Create
        </NavLink>
        <NavLink to="/attend" className={({ isActive }) => (isActive ? 'active' : '')}>
          Attend
        </NavLink>
        <NavLink to="/login" className={({ isActive }) => (isActive ? 'active' : '')}>
          Login
        </NavLink>
      </nav>

      <main className="container">
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/" element={<PrivateRoute><Dashboard /></PrivateRoute>} />
          <Route path="/create" element={<PrivateRoute><CreateMeeting /></PrivateRoute>} />
          <Route path="/qr/:id" element={<PrivateRoute><QRPage /></PrivateRoute>} />
          <Route path="/attend" element={<PrivateRoute><AttendPage /></PrivateRoute>} />
        </Routes>
      </main>
    </div>
  );
}
