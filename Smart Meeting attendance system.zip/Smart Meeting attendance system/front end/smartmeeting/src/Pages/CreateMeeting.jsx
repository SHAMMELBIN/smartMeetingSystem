import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import API from '../api.js';

export default function CreateMeeting() {
  const [topic, setTopic] = useState('');
  const [amount, setAmount] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await API.post('/meetings', {
        topic,
        amount,
        startTime,
        endTime,
      });      
      navigate(`/qr/${res.data.meetings._id}`);
    } catch (err) {
        console.log(err)
      alert('Error creating meeting');
    }
  };

  return (
    <div className="create-meeting">
      <h2 className="create-title">🗓️ Create a New Meeting</h2>

      <form onSubmit={handleSubmit} className="create-form">
        <div className="form-group">
          <label>Meeting Topic</label>
          <input
            type="text"
            placeholder="Enter meeting topic"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Amount</label>
          <input
            type="number"
            placeholder="Amount (optional)"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
        </div>

        <div className="form-group">
          <label>Start Time</label>
          <input
            type="datetime-local"
            value={startTime}
            onChange={(e) => setStartTime(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>End Time</label>
          <input
            type="datetime-local"
            value={endTime}
            onChange={(e) => setEndTime(e.target.value)}
            required
          />
        </div>

        <button type="submit" className="create-btn">
          Create Meeting
        </button>
      </form>
    </div>
  );
}
