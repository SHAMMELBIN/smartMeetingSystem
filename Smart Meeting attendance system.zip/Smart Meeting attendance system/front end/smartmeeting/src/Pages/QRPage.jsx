import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import API from '../api.js';
import { QRCodeCanvas } from 'qrcode.react';

export default function QRPage() {
  const { id } = useParams();
  const [qrUrl, setQrUrl] = useState('');

  useEffect(() => {
    API.get('/meetings')
      .then((res) => {
        const meeting = res.data.find((m) => m._id === id);
        if (meeting?.qrData) {
          setQrUrl(JSON.stringify(meeting.qrData));
        }
      })
      .catch(() => alert('Error loading QR'));
  }, [id]);

  return (
    <div>
      <h2>Meeting QR</h2>
      {qrUrl ? <QRCodeCanvas value={qrUrl} size={256} /> : <p>Loading QR...</p>}
    </div>
  );
}
