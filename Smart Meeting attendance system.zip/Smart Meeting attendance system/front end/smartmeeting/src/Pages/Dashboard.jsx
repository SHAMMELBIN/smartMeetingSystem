import { useEffect, useState } from 'react';
import API from '../api.js';

export default function Dashboard() {
  const [meetings, setMeetings] = useState([]);

  useEffect(() => {
    API.get('/meetings')
      .then((res) => setMeetings(res.data))
      .catch(() => console.error('Failed to load meetings'));
  }, []);

  return (
    <div className="dashboard">
      <h2 className="dashboard-title">📅 All Meetings</h2>
      {meetings.length === 0 ? (
        <p className="no-meetings">No meetings found. Create one to get started!</p>
      ) : (
        <ul className="meeting-list">
          {meetings.map((m) => (
            <li key={m._id} className="meeting-card">
              <div className="meeting-header">
                <h3>{m.topic}</h3>
              </div>
              <p>
                <strong>Start:</strong>{' '}
                {new Date(m.startTime).toLocaleString()}
              </p>
              <p>
                <strong>End:</strong>{' '}
                {new Date(m.endTime).toLocaleString()}
              </p>
              <p>
                <strong>Meeting ID:</strong> {m._id}
              </p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
