import React, { useEffect, useState } from 'react';
import API from '../api.js';
import { QRCodeCanvas } from 'qrcode.react';

export default function AttendPage() {
  const [meetings, setMeetings] = useState([]);
  const [selectedMeeting, setSelectedMeeting] = useState('');
  const [selectedQR, setSelectedQR] = useState('');
  const [status, setStatus] = useState('');

  // 🟢 Load all meetings on mount
  useEffect(() => {
    API.get('/meetings')
      .then((res) => setMeetings(res.data))
      .catch(() => console.error('Failed to load meetings'));
  }, []);

  // 🟡 When meeting is selected, extract its QR data
  useEffect(() => {
    if (!selectedMeeting) {
      setSelectedQR('');
      return;
    }

    const meeting = meetings.find((m) => m._id === selectedMeeting);
    if (meeting?.qrData) {
      setSelectedQR(JSON.stringify(meeting.qrData));
    } else {
      setSelectedQR('');
    }
  }, [selectedMeeting, meetings]);

  // 🟠 Handle attendance marking
  const handleAttend = async () => {
    if (!selectedMeeting) return alert('Please select a meeting first');
    try {
      await API.post(`/meetings/${selectedMeeting}/attend`);
      setStatus('✅ Attendance marked successfully!');
    } catch {
      setStatus('❌ Failed to mark attendance.');
    }
  };

  return (
    <div className="attend-page">
      <h2 className="attend-title">🙋‍♂️ Mark Attendance</h2>

      <div className="attend-form">
        <label htmlFor="meetingSelect">Select a Meeting:</label>
        <select
          id="meetingSelect"
          value={selectedMeeting}
          onChange={(e) => setSelectedMeeting(e.target.value)}
        >
          <option value="">-- Choose a Meeting --</option>
          {meetings.map((m) => (
            <option key={m._id} value={m._id}>
              {m.topic} ({new Date(m.startTime).toLocaleString()})
            </option>
          ))}
        </select>

        {/* 🔵 Show QR Code if selected */}
        {selectedQR && (
          <div className="qr-section">
            <h3>📱 Scan to Mark Attendance</h3>
            <QRCodeCanvas value={selectedQR} size={200} className="qr-code" />
          </div>
        )}

        <button onClick={handleAttend} className="attend-btn">
          Mark Attendance
        </button>

        {status && <p className="attend-status">{status}</p>}
      </div>
    </div>
  );
}
