import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import API from './api';
import { FaEye, FaEyeSlash } from "react-icons/fa"; // 👁️ icons


export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
   const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await API.post('/auth/login', { email, password });
      localStorage.setItem('token', res.data.accessToken);
      localStorage.setItem('refreshToken', res.data.refreshToken);
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed');
    }
  };

  return (
  <div className="login-container">
    <div className="login-card">
      <h2 className="login-title">Smart Meeting Login</h2>

      <form onSubmit={handleSubmit} className="login-form">
        <input
          type="email"
          placeholder="Email Address"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="login-input"
          required
        />

        <div className="password-wrapper">
          <input
            type={showPassword ? "text" : "password"}
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="login-input password-input"
            required
          />
          <span
            className="toggle-password"
            onClick={() => setShowPassword((prev) => !prev)}
            title={showPassword ? "Hide Password" : "Show Password"}
          >
            {showPassword ? <FaEyeSlash /> : <FaEye />}
          </span>
        </div>

        <button type="submit" className="login-button">Login</button>
      </form>

      {/* ✅ Registration Button */}
      <button
        className="register-button"
        onClick={() => navigate("/register")}
      >
        Create an Account
      </button>

      {error && <p className="login-error">{error}</p>}
      <p className="login-footer">© 2025 Smart Meeting Attendance System</p>
    </div>
  </div>
);

}
