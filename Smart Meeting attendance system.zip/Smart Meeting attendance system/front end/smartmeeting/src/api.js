import axios from 'axios';
import { jwtDecode } from 'jwt-decode';

const API = axios.create({
  baseURL: process.env.REACT_APP_API || 'http://localhost:5000/api',
});

API.interceptors.request.use(async (config) => {
  let token = localStorage.getItem('token');
  const refreshToken = localStorage.getItem('refreshToken');

  if (token) {
    const decoded = jwtDecode(token);
    if (decoded.exp * 1000 < Date.now() && refreshToken) {
      try {
        const res = await axios.post(`${API.defaults.baseURL}/auth/refresh`, { refreshToken });
        token = res.data.accessToken;
        localStorage.setItem('token', token);
        localStorage.setItem('refreshToken', res.data.refreshToken);
      } catch (err) {
        console.error('Token refresh failed:', err);
        localStorage.removeItem('token');
        localStorage.removeItem('refreshToken');
        window.location.href = '/login';
      }
    }
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default API;